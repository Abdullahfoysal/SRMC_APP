package com.example.latestsplash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private int SPLASH_TIME_OUT=2000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ((ImageView) findViewById(R.id.imageView2)).startAnimation(AnimationUtils.loadAnimation(this,R.anim.test));
//        ((ImageView) findViewById(R.id.imageView2)).startAnimation(AnimationUtils.loadAnimation(this,R.anim.mytransition));
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent homeIntent = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(homeIntent);
                finish();
            }
        },SPLASH_TIME_OUT);
    }



//public class MainActivity extends AppCompatActivity {
//    private int SPLASH_TIME_OUT=1000;
//    private ImageView image ;
////    private int[]  id={R.drawable.icon1,R.drawable.icon2,R.drawable.icon3,R.drawable.icon4,R.drawable.icon5,R.drawable.icon6,R.drawable.icon7,R.drawable.icon8,R.drawable.icon9,R.drawable.icon10};
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
////        load(0);
//        ((ImageView) findViewById(R.id.imageView2)).setImageResource(R.drawable.icon);
////        updateCurrentTimeAndDate();
//
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                Intent homeIntent = new Intent(MainActivity.this, HomeActivity.class);
//                startActivity(homeIntent);
//                finish();
//            }
//        },SPLASH_TIME_OUT);
//    }

//    private void load(int number)
//    {
//        image=(ImageView) findViewById(R.id.imageView2);
//        image.setImageResource(id[number]);
//
//    }

//    private void updateCurrentTimeAndDate(){
//        Thread timeAndDate=new Thread(){
//            int number=0;
//            @Override
//            public void run() {
//
//                try {
//                    while(!isInterrupted()){
//                        Thread.sleep(290);
//                        runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//                                System.out.println(number);
//                                if(number==10)number--;
//                                load(number++);
//                                if(number>=10) {
//                                    try{
//                                        Thread.currentThread().stop();
//                                    }
//                                    catch (Exception e)
//                                    {
//                                        e.printStackTrace();
//                                    }
//                                }
//                            }
//                        });
//                    }
//                }catch (Exception e){
//                    e.printStackTrace();
//                }
//            }
//        };
//        timeAndDate.start();
//    }

}
